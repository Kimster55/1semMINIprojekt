### [View the Cards](https://bmorelli25.github.io/flexbox-card-tutorial/)

![Simple HTML Cards](https://github.com/bmorelli25/flexbox-card-tutorial/blob/master/imgs/flexbox-cards.PNG "Simple HTML Cards")
